var typed = new Typed(".multiple-text", {
                                        strings: ["Frontend Developer", "Student", "Joy to be around 😊", "Software Engineer"],
                                        typeSpeed: 100,
                                        backSpeed: 175,
                                        backDelay: 100,
                                        loop: true
})

var typed = new Typed(".greeting-text", {
                                        strings: ["Hello, I am", "Hola yo soy", "你好，我是", "Je m'appelle", "Ciao io sono", "私は"],
                                        typeSpeed: 100,
                                        backSpeed: 175,
                                        backDelay: 100,
                                        loop: true
}
)

